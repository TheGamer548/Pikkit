# Example Package

This is a simple example package. You can use
[Github-flavored Markdown](https://guides.github.com/features/mastering-markdown/)
to write your content.

# Features
## You can use add package to add a custom package example : pikit.add_package("pygame")
## And, It Works !!
